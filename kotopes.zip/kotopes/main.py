import os
import json
import random
import asyncio
import threading
import time
from datetime import datetime, timedelta
import telebot
from telebot import types
from pyrogram import Client
from pyrogram.types import Chat
from pyrogram.errors import UserAlreadyParticipant, InviteHashExpired, InviteHashInvalid
from database import MySqlDatabase
from settings import bot_token, user_id, debug_id
from utils import (
    comment_post,
    get_posts,
    get_session,
    get_session_files,
    delete_session,
)

# Инициализация бота и базы данных
bot = telebot.TeleBot(bot_token)
db = MySqlDatabase()


@bot.message_handler(commands=["add_channel"])
def add_channel(message):
    value = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    if value:
        db.add_channel(value.replace("@", ""))
        bot.reply_to(message, f"Добавлен канал: {value}")
    else:
        bot.reply_to(message, "Ошибка: укажи канал после команды")


@bot.message_handler(commands=["change_api_id"])
def change_api_id(message):
    value = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    if value:
        db.set_api_id(value)
        bot.reply_to(message, f"API ID изменён на: {value}")
    else:
        bot.reply_to(message, "Ошибка: укажи API ID после команды.")


@bot.message_handler(commands=["change_api_hash"])
def change_api_hash(message):
    value = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    if value:
        db.set_api_hash(value)
        bot.reply_to(message, f"API Hash изменён на: {value}")
    else:
        bot.reply_to(message, "Ошибка: укажи API Hash после команды.")


@bot.message_handler(commands=["change_message_text"])
def change_message_text(message):
    text = message.html_text
    text = text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    if text:
        db.set_message_text(text)
        bot.reply_to(
            message,
            "Поменял сообщение на:",
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
        bot.reply_to(message, text, parse_mode="HTML")
    else:
        bot.reply_to(message, "Ошибка: укажи текст после команды.", parse_mode="HTML")


@bot.message_handler(commands=["start"])
def start(message):
    markup = types.InlineKeyboardMarkup()
    button1 = types.InlineKeyboardButton(text="Каналы", callback_data="view_channels")
    button2 = types.InlineKeyboardButton(text="Сессии", callback_data="view_sessions")
    markup.add(button1, button2)
    bot.reply_to(message, "Меню:", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    callback_data = call.data
    keyboard = None
    back_button = types.InlineKeyboardButton(callback_data="goHome", text="◀️ Назад")

    if callback_data == "view_channels":
        keyboard = types.InlineKeyboardMarkup()
        channels = db.get_channels()
        for channel in channels:
            group_button = types.InlineKeyboardButton(
                url=f'https://t.me/{channel["username"]}',
                text="@" + channel["username"],
            )
            delete_button = types.InlineKeyboardButton(
                callback_data=f'deleteChannel:{channel["username"]}', text="❌ Удалить"
            )
            keyboard.add(group_button, delete_button)
        keyboard.add(back_button)

    elif callback_data == "goHome":
        keyboard = types.InlineKeyboardMarkup()
        button1 = types.InlineKeyboardButton(
            text="Каналы", callback_data="view_channels"
        )
        button2 = types.InlineKeyboardButton(
            text="Сессии", callback_data="view_sessions"
        )
        keyboard.add(button1, button2)

    elif callback_data.split(":")[0] == "deleteChannel":
        db.delete_channel(callback_data.split(":")[1])
        keyboard = types.InlineKeyboardMarkup()
        channels = db.get_channels()
        for channel in channels:
            group_button = types.InlineKeyboardButton(
                url=f'https://t.me/{channel["username"]}',
                text="@" + channel["username"],
            )
            delete_button = types.InlineKeyboardButton(
                callback_data=f'deleteChannel:{channel["username"]}', text="❌ Удалить"
            )
            keyboard.add(group_button, delete_button)
        keyboard.add(back_button)

    elif callback_data == "view_sessions":
        keyboard = types.InlineKeyboardMarkup()
        sessions = get_session_files()
        for session in sessions:
            group_button = types.InlineKeyboardButton(callback_data="qwe", text=session)
            delete_button = types.InlineKeyboardButton(
                callback_data=f"deleteSession:{session}", text="❌ Удалить"
            )
            keyboard.add(group_button, delete_button)
        keyboard.add(back_button)
        bot.edit_message_text(
            "Чтобы добавить сессию, отправьте .session файл",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard,
        )
        return

    elif callback_data.split(":")[0] == "deleteSession":
        print(callback_data.split(":")[1])
        delete_session(callback_data.split(":")[1])
        keyboard = types.InlineKeyboardMarkup()
        sessions = get_session_files()
        for session in sessions:
            group_button = types.InlineKeyboardButton(callback_data="qwe", text=session)
            delete_button = types.InlineKeyboardButton(
                callback_data=f"deleteSession:{session}", text="❌ Удалить"
            )
            keyboard.add(group_button, delete_button)
        keyboard.add(back_button)

    elif callback_data == "qwe":
        return

    bot.edit_message_text(
        "Меню:",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard,
    )


bot.set_my_commands(
    [
        telebot.types.BotCommand("start", "Меню:"),
        telebot.types.BotCommand("add_channel", "Добавить канал"),
        telebot.types.BotCommand("change_api_id", "Изменить API ID"),
        telebot.types.BotCommand("change_api_hash", "Изменить API Hash"),
        telebot.types.BotCommand("change_message_text", "Изменить текст сообщения"),
    ]
)


# Глобальные переменные
clients = {}  # Глобальный словарь клиентов для каждой сессии
queue = asyncio.Queue()  # Очередь для необработанных каналов


@bot.message_handler(content_types=["document"])
def handle_session_files(message):
    if message.document:
        file = message.document
        file_name = file.file_name
        if file_name.endswith(".session"):
            file_info = bot.get_file(file.file_id)
            file_path = os.path.join(os.getcwd(), file_name)
            downloaded_file = bot.download_file(file_info.file_path)
            with open(file_path, "wb") as f:
                f.write(downloaded_file)
            bot.reply_to(
                message, f"Файл {file_name} успешно сохранен в текущей директории."
            )
        else:
            bot.reply_to(message, "Ошибка: файл должен иметь расширение .session")


banned = {}


# Функция создания клиентов для всех сессий
def create_clients():
    sessions = get_session_files()
    for i, session in enumerate(sessions):
        api = db.get_api_info()
        if not api:
            print("ОШИБКА: API данные не найдены в базе данных!")
            print("Используйте команды бота:")
            print("  /change_api_id <ваш_api_id>")
            print("  /change_api_hash <ваш_api_hash>")
            print("Чтобы добавить API данные в базу данных.")
            return
        
        # Створюємо клієнт БЕЗ проксі
        clients[session] = Client(
            session, api_id=api["api_id"], api_hash=api["api_hash"]
        )

        banned[session] = []


joined = []


# Функция подключения к каналу
async def join_if_needed(client: Client, channel_username: str, session: str):
    if session not in banned:
        banned[session] = []
    try:
        if session in banned and channel_username in banned[session]:
            return False
        chat: Chat = await client.get_chat(channel_username)
        if not chat or not chat.id:
            return False
    except Exception as e:
        print(f"[{client.name}] Не вдалося отримати чат @{channel_username}: {e}")
        if "Username not found" in str(e) or "CHANNEL_PRIVATE" in str(e):
            banned[session].append(channel_username)
        return False
    try:
        await client.join_chat(channel_username)
        print(f"[{client.name}] Успішно приєднався до @{channel_username}")
        return True
    except UserAlreadyParticipant:
        return True
    except (InviteHashExpired, InviteHashInvalid):
        print(
            f"[{client.name}] Невірне або прострочене посилання на запрошення: @{channel_username}"
        )
        return False
    except Exception as e:
        print(f"[{client.name}] Не вдалося приєднатись до @{channel_username}: {e}")
        if "Username not found" in str(e) or "CHANNEL_PRIVATE" in str(e):
            banned[session].append(channel_username)
        return False


# Обработка одного канала одной сессией
async def process_channel(session: str, client: Client):
    while True:
        channel_name = await queue.get()  # Получаем канал из очереди
        try:
            response = await join_if_needed(client, channel_name, session)
            if response:
                posts = await get_posts(
                    session, channel_name, client.api_id, client.api_hash, client
                )
                for post in posts:
                    post_id = post.id
                    post_text = (
                        post.text
                        if post.text
                        else post.caption if post.caption else None
                    )
                    time_obj = datetime.strptime(str(post.date), "%Y-%m-%d %H:%M:%S")
                    if datetime.now() <= time_obj + timedelta(seconds=30):
                        if db.is_post_commented(channel_name, post_id):
                            print(
                                f"[{session}] post #{post_id} in {channel_name} already commented. Skipping."
                            )
                            await queue.put(channel_name)
                        else:
                            print(
                                f"[{session}] post #{post_id} in {channel_name} not commented. Commenting..."
                            )
                            try:
                                await comment_post(
                                    session,
                                    post_id,
                                    channel_name,
                                    db.get_message_text(),
                                    client.api_id,
                                    client.api_hash,
                                    bot,
                                    client,
                                )
                                db.add_commented_post(channel_name, post_id)
                                await queue.put(channel_name)
                            except Exception as e:
                                bot.send_message(
                                    chat_id=user_id,
                                    text=f"Сессия {session} была удалена. Причина: {e}",
                                )
                                bot.send_message(
                                    chat_id=debug_id,
                                    text=f"Сессия {session} была удалена. Причина: {e}",
                                )
                                delete_session(session)
                                await queue.put(channel_name)
            else:
                await queue.put(channel_name)  # Возвращаем канал в очередь
        except Exception as e:
            bot.send_message(
                chat_id=user_id,
                text=f"Сессия {session} не получила историю сообщений в @{channel_name}. Вероятно бан. Причина: {e}",
            )
            bot.send_message(
                chat_id=debug_id,
                text=f"Сессия {session} не получила историю сообщений в @{channel_name}. Вероятно бан. Причина: {e}",
            )
            await queue.put(channel_name)  # Возвращаем канал в очередь
        finally:
            await queue.put(channel_name)
            queue.task_done()


# Основной цикл
async def spammer_loop():
    create_clients()  # Создаем клиенты для всех сессий
    print(banned)
    tasks = []
    for session, client in clients.items():
        await client.start()  # Запускаем клиент
        tasks.append(asyncio.create_task(process_channel(session, client)))

    while True:
        channels = db.get_channels()
        for channel in channels:
            await queue.put(channel["username"])  # Добавляем каналы в очередь
        await queue.join()  # Ждем, пока все каналы будут обработаны
        await asyncio.sleep(1)

        
# Функция создания клиентов для всех сессий
def create_clients():
    sessions = get_session_files()
    for i, session in enumerate(sessions):
        api = db.get_api_info()
        if not api:
            print("ОШИБКА: API данные не найдены в базе данных!")
            print("Используйте команды бота:")
            print("  /change_api_id <ваш_api_id>")
            print("  /change_api_hash <ваш_api_hash>")
            print("Чтобы добавить API данные в базу данных.")
            return
        
        clients[session] = Client(
            session, api_id=api["api_id"], api_hash=api["api_hash"]
        )

        banned[session] = []        


if __name__ == "__main__":
    threading.Thread(target=lambda: asyncio.run(spammer_loop())).start()
    bot.polling(none_stop=True)