import os

import telebot
from pyrogram import Client
from pyrogram.enums import ParseMode

from settings import user_id, debug_id


def get_session_files():
    return [os.path.splitext(f)[0] for f in os.listdir() if f.endswith(".session")]

def get_session():
    return get_session_files()[0] if len(get_session_files()) > 0 else None

def delete_session(session):
    try:
        os.remove(session + ".session")
        print(f"Файл {session} успешно удален.")
    except FileNotFoundError:
        print(f"Ошибка: файл {session} не найден.")
    except PermissionError:
        print(f"Ошибка: у вас нет прав для удаления файла {session}.")
    except Exception as e:
        print(f"Ошибка: {e}")


async def comment_post(session, post_id, channel, text, api_id, api_hash, bot, client):
    try:
        await client.send_message(channel, text, reply_to_message_id=post_id, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        print("-")
        bot.send_message(chat_id=user_id, text=f'Отправил сообщение {text} в @{channel} с сессией {session}', parse_mode='Html', link_preview_options=telebot.types.LinkPreviewOptions(is_disabled=True))
        bot.send_message(chat_id=debug_id, text=f'Отправил сообщение {text} в @{channel} с сессией {session}',
                         parse_mode='Html', link_preview_options=telebot.types.LinkPreviewOptions(is_disabled=True))
    except Exception as e:
        print(f'Exception while commenting post {e}')
        return None
"""
async def is_session_good(session, api_id, api_hash):
    try:
        async with Client(session, api_id, api_hash) as app:
            await app.get_me()
            return True
    except Exception as e:
        print(e)
        return False
"""
async def get_posts(session, channel, api_id, api_hash, client):
    messages = client.get_chat_history(channel, limit=20)
    posts = [msg async for msg in messages if msg.views is not None]
    return posts




