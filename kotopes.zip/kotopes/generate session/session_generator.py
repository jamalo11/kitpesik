from pyrogram import Client

# Указываем данные для сессии
api_id = '27214522' #api id https://my.telegram.org/apps
api_hash = '7cb2e7f03c6296fa8f21e97b6f302062' #api hash https://my.telegram.org/apps

# Вводим имя сессии
session_name = input("Введите название сессии: ")

# Создаем клиент сессии
app = Client(session_name, api_id=api_id, api_hash=api_hash)

# Запускаем клиент
app.start()

# Твой код для работы с Telegram API, например:
me = app.get_me()
print(me)

# После работы, обязательно завершить сессию
app.stop()
