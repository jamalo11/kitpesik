"""
Database class for SQLite
"""
import sqlite3
import os


class MySqlDatabase:
    def __init__(self):
        self.db_path = "database.db"
        self.connection = None
        self.ensure_tables()

    def connect(self):
        if not self.connection:
            self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
            self.connection.row_factory = sqlite3.Row  # Для получения результатов как словарей

    def ensure_tables(self):
        self.connect()
        queries = [
            """
            CREATE TABLE IF NOT EXISTS channels (
              username TEXT PRIMARY KEY
            );
            """,
            """
            CREATE TABLE IF NOT EXISTS commented_posts (
              channel TEXT NOT NULL,
              post_id INTEGER NOT NULL,
              UNIQUE(channel, post_id)
            );
            """,
            """
            CREATE TABLE IF NOT EXISTS general (
              api_id INTEGER NOT NULL,
              api_hash TEXT NOT NULL,
              message TEXT NOT NULL,
              PRIMARY KEY (api_id, api_hash)
            );
            """
        ]
        for query in queries:
            self.execute_commit(query)

    def execute(self, query, params=None):
        self.connect()
        cursor = self.connection.cursor()
        cursor.execute(query, params or ())
        rows = cursor.fetchall()
        # Конвертируем sqlite3.Row в словари для совместимости
        return [dict(row) for row in rows]

    def execute_one(self, query, params=None):
        self.connect()
        cursor = self.connection.cursor()
        cursor.execute(query, params or ())
        row = cursor.fetchone()
        # Конвертируем sqlite3.Row в словарь для совместимости
        return dict(row) if row else None

    def execute_commit(self, query, params=None):
        self.connect()
        cursor = self.connection.cursor()
        cursor.execute(query, params or ())
        self.connection.commit()

    def get_channels(self):
        return self.execute("SELECT * FROM channels")

    def add_channel(self, channel):
        self.execute_commit("INSERT OR IGNORE INTO channels(username) VALUES(?)", (channel,))

    def delete_channel(self, channel):
        self.execute_commit("DELETE FROM channels WHERE username = ?", (channel,))

    def get_api_info(self):
        return self.execute_one("SELECT * FROM general")

    def set_api_id(self, api_id):
        # Перевіряємо чи існує запис
        existing = self.execute_one("SELECT * FROM general")
        if existing:
            self.execute_commit("UPDATE general SET api_id = ?", (api_id,))
        else:
            # Створюємо новий запис з дефолтними значеннями
            self.execute_commit("INSERT INTO general (api_id, api_hash, message) VALUES (?, '', 'Привет! 👋')", (api_id,))

    def set_api_hash(self, api_hash):
        # Перевіряємо чи існує запис
        existing = self.execute_one("SELECT * FROM general")
        if existing:
            self.execute_commit("UPDATE general SET api_hash = ?", (api_hash,))
        else:
            # Створюємо новий запис з дефолтними значеннями
            self.execute_commit("INSERT INTO general (api_id, api_hash, message) VALUES (0, ?, 'Привет! 👋')", (api_hash,))

    def set_message_text(self, message_text):
        # Перевіряємо чи існує запис
        existing = self.execute_one("SELECT * FROM general")
        if existing:
            self.execute_commit("UPDATE general SET message = ?", (message_text,))
        else:
            # Створюємо новий запис з дефолтними значеннями
            self.execute_commit("INSERT INTO general (api_id, api_hash, message) VALUES (0, '', ?)", (message_text,))

    def get_message_text(self):
        """Получить сохраненный текст сообщения из базы данных"""
        result = self.execute_one("SELECT message FROM general")
        return result['message'] if result else "Привет! 👋"

    def is_post_commented(self, channel_id, post_id):
        res = self.execute("SELECT * FROM commented_posts WHERE channel=? AND post_id=?", (channel_id, post_id))
        return len(res) > 0

    def add_commented_post(self, channel_id, post_id):
        self.execute_commit("INSERT OR IGNORE INTO commented_posts(channel, post_id) VALUES(?, ?)", (channel_id, post_id))
        return True

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None